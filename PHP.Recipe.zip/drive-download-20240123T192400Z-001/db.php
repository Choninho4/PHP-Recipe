<?php

$servername = "localhost";
$username = "root";
$password = "Omra@2002";
$dbname = "recipe_app";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Afficher une erreur générique en production
    echo "Erreur de connexion à la base de données. Veuillez contacter l'administrateur du site.";

    // En mode de développement, vous pourriez afficher les détails de l'erreur
    // echo "Erreur de connexion à la base de données : " . $e->getMessage();

    error_log("Erreur de connexion à la base de données : " . $e->getMessage(), 0);
    die();
}
?>
